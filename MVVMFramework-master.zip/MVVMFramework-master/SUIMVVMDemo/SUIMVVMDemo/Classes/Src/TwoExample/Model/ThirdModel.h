//
//  ThirdModel.h
//  MVVMFramework
//
//  Created by yuantao on 16/1/7.
//  Copyright © 2016年 momo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThirdModel : NSObject

@property (nonatomic, copy) NSString *publisher;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *summary;

@end
