//
//  FirstModel.h
//  XTMultipleTables
//
//  Created by momo on 15/12/5.
//  Copyright © 2015年 teason. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FirstModel : NSObject

@property (nonatomic, copy) NSString *publisher;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *summary;

@end
